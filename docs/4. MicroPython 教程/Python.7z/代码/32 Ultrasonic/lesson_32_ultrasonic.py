from machine import Pin
import time

# 定义超声波测距模块的控制引脚
Trig = Pin(13, Pin.OUT, 0) 
Echo = Pin(12, Pin.IN, 0)

distance = 0 # 将初始距离定义为0
soundVelocity = 340 # 声速

# getDistance()函数用于驱动超声波模块测量距离
def getDistance():
    # 发送10μs触发脉冲
    Trig.value(1)
    time.sleep_us(10)
    Trig.value(0)
    
    # 等待Echo引脚拉高（超声波发射）
    while not Echo.value():
        pass
    pingStart = time.ticks_us()  # 记录开始时间
    
    # 等待Echo引脚拉低（回波接收）
    while Echo.value():
        pass
    pingStop = time.ticks_us()  # 记录结束时间
    
    # 计算时间差（除以2得到单向时间），转换为距离（厘米）
    pingTime = time.ticks_diff(pingStop, pingStart) // 2
    distance = int(soundVelocity * pingTime // 10000)  # 340×t/(2×10^-4)
    return distance

# 延时2秒，等待超声波模块稳定
# 打印每500毫秒从超声波模块获得的数据
time.sleep(2)
while True:
    time.sleep_ms(500)
    distance = getDistance()
    print("Distance: ", distance, "cm")